#pragma 

#include <iostream>

using namespace std;

class Point
{
	int a = 0;
	int b = 0;

	const int cia;
	int& pa;

public:
	Point();
	
};

