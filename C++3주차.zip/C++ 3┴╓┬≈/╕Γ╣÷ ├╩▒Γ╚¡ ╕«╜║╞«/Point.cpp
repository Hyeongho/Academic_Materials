#include "Point.h"

Point::Point() : cia(1), pa(a)
{
	cout << "const: " << cia << ", pa: " << pa << endl;
}