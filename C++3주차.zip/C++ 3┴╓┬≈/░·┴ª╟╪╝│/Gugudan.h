#pragma once

#include <iostream>

using namespace std;

class Gugudan
{
	int a;

public:
	void Set(int _a);
	int Get();

	void guguDan(int _a);
};