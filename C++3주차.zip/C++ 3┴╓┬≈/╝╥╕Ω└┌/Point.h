#pragma once

#include <iostream>

using namespace std;

class Point
{
	int a;
	int b;

public:

	Point(int _a, int _b);
	~Point();
};