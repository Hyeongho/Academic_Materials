#include "Point.h"

int main()
{
	Point p(1, 2);
}