#include <iostream>
#include "Point.h"

int main()
{
	Point p1;
	Point p2(1, 2);

	p1.getPoint();

	p2.getPoint();

}
