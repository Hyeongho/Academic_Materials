#pragma once

#include <iostream>

using namespace std;

class Point
{
	int a, b;

public:
	Point();
	Point(int _a, int _b);

	void getPoint();

};