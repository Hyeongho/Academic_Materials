#include "Point.h"

int main()
{
	Line l(1, 2);

	Point p(3, 4);

	l.print();

	p.print();
}