class Vehicle
{
	int speed;
};

class Car : public Vehicle
{
	int speed;

	int gear;
};