#pragma once

#include <iostream>

using namespace std;

class Point
{
private:
	int sum;

protected:


public:
	int a;
	int b;

	void Sum(int a, int b);
	void getSum();
};

