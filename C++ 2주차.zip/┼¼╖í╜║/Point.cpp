#include "Point.h"

void Point::Sum(int a, int b)
{
	sum = a + b;
}

void Point::getSum()
{
	cout << sum << endl;
}