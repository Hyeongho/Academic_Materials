#pragma once

#include <iostream>

using namespace std;

class Shape
{
public:
	int x;
	int y;

	Shape();
	~Shape();
};

