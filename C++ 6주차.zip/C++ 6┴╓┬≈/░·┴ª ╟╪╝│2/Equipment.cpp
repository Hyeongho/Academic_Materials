#include "Equipment.h"

Equipment::Equipment()
{
	lv = 0;
}

Equipment::~Equipment()
{
}
