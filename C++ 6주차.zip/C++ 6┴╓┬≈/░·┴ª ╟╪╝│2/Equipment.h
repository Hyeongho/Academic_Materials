#pragma once

#include "Item.h"

class Equipment : public Item
{
protected:
	int lv;

public:
	Equipment();
	~Equipment();

};

