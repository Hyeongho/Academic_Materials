#include "Item.h"

Item::Item()
{
	name = " ";
}

Item::~Item()
{
}
